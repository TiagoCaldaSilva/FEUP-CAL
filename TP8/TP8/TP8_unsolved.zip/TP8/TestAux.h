#ifndef TEST_AUX_H_
#define TEST_AUX_H_

#include "Graph.h"

/**
 * Auxiliary functions to tests...
 *
 */
Graph<int> createTestFlowGraph();

#endif //TEST_AUX_H_
